﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateProblem
{
    public class DateIssue
    {
        // Find values of day and month from
        // offset of result year.

        static int actualDay;
        static int actualMonth;
        int actualYear;
        static int[] monthArr = { 0, 31, 28, 31, 30, 31, 30,
                    31, 31, 30, 31, 30, 31 };
        public DateIssue(int day, int month, int year)
        {
            day = actualDay;
            month = actualMonth;
            year = actualYear;
        }

        public int day
        {
            get { return actualDay; }
        }
        public int month
        {
            get { return actualMonth; }
        }

        public int year
        {
            get { return actualYear; }
        }
        // Return if year is leap year or not.
        static bool isLeap(int y)
        {
            if (y % 100 != 0 && y % 4 == 0 || y % 400 == 0)
                return true;

            return false;
        }

        // Add x days to the given date.
        public  void addDays(int d1, int m1, int y1, int x)
        {
            int daysGone = goneDays(d1, m1, y1);
            int remDays;
            remDays = isLeap(y1) ? 366 - daysGone : 365 - daysGone;
            
            // actualYear is going to store result year and
            // offset2 is going to store offset days
            // in result year.

            
            int offsetDays;

            if (x < remDays)
            {
                actualYear = y1;
                offsetDays = daysGone + x;
            }
            else
            {
                x = x - remDays;
                actualYear = y1 + 1;
                int days = isLeap(actualYear) ? 366 : 365;
                while (x >= days)
                {
                    x = x - days;
                    actualYear++;
                    days = isLeap(actualYear) ? 366 : 365;
                }
                offsetDays = x;
            }
            revoffsetDays(offsetDays, actualYear);
            Console.WriteLine("the Revised date is " + actualDay + "-" +
                                actualMonth + "-" + actualYear);
        }


        //Given a date, returns number of days elapsed
        // from the beginning of the current year (1st
        // jan)
        static int goneDays(int d2, int m2, int y2)
        {
            int offset = d2;

            if (isLeap(y2))
                monthArr[2] = 29;

            for (int i = 1; i <= 12; i++)
            {
                if (m2 - 1 == i)
                {
                    offset = offset + monthArr[i];
                    break;
                }
                else
                    offset = offset + monthArr[i];
            }
            return offset;

        }

        // Given a year and days elapsed in it, finds the date

        static void revoffsetDays(int d2, int y2)
        {

            if (isLeap(y2))
                monthArr[2] = 29;

            int i;
            for (i = 1; i <= 12; i++)
            {
                if (d2 <= monthArr[i])
                    break;
                d2 = d2 - monthArr[i];
            }
            actualDay = d2;
            actualMonth = i;
        }

    }
}
