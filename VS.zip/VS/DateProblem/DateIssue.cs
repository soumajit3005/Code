﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateProblem
{
    public class DateIssue
    {
        // Find values of day and month from
        // offset of result year.

        static int actualDay;
       static int actualMonth;
        int actualYear;

        public DateIssue(int day, int month, int year)
        {
            day = actualDay;
            month = actualMonth;
            year = actualYear;
        }

        public int day
        {
            get { return actualDay; }
        }
        public int month
        {
            get { return actualMonth; }
        }

        public int year
        {
            get { return actualYear; }
        }
        // Return if year is leap year or not.
        static bool isLeap(int y)
        {
            if (y % 100 != 0 && y % 4 == 0 || y % 400 == 0)
                return true;

            return false;
        }

        // Add x days to the given date.
        public void addDays(int d1, int m1, int y1, int x)
        {
            int daysGone = goneDays(d1, m1, y1);
            int remDays;
            if (isLeap(y1))
            {
                remDays = 366 - daysGone;
            }
            else
            {
                remDays = 365 - daysGone;
            }

            // actualYear is going to store result year and
            // offset2 is going to store offset days
            // in result year.

            
            int offsetDays;

            if (x < remDays)
            {
                actualYear = y1;
                offsetDays = daysGone + x;
            }
            else
            {
                x = x - remDays;
                actualYear = y1 + 1;
                int days = isLeap(actualYear) ? 366 : 365;
                while (x >= days)
                {
                    x = x - days;
                    actualYear++;
                    days = isLeap(actualYear) ? 366 : 365;
                }
                offsetDays = x;
            }
            revoffsetDays(offsetDays, actualYear);
            Console.WriteLine("the Revised date is " + actualDay + "/" +
                                actualMonth + "/" + actualYear);
        }


        //Given a date, returns number of days elapsed
        // from the beginning of the current year (1st
        // jan)
        static int goneDays(int d2, int m2, int y2)
        {
            int offset = d2;

            if (m2 - 1 == 1)
                offset = offset + 31;
            if (m2 - 1 == 2)
                offset = offset + 59;
            if (m2 - 1 == 3)
                offset = offset + 90;
            if (m2 - 1 == 4)
                offset = offset + 120;
            if (m2 - 1 == 5)
                offset = offset + 151;
            if (m2 - 1 == 6)
                offset = offset + 181;
            if (m2 - 1 == 7)
                offset = offset + 212;
            if (m2 - 1 == 8)
                offset = offset + 243;
            if (m2 - 1 == 9)
                offset = offset + 273;
            if (m2 - 1 == 10)
                offset = offset + 304;
            if (m2 - 1 == 11)
                offset = offset + 335;

            if (isLeap(y2) && m2 > 2)
                offset = offset + 1;


            return offset;

        }

        // Given a year and days elapsed in it, finds the date

        static void revoffsetDays(int d2, int y2)
        {
            int[] month = { 0, 31, 28, 31, 30, 31, 30,
                    31, 31, 30, 31, 30, 31 };

            if (isLeap(y2))
                month[2] = 29;

            int i;
            for (i = 1; i <= 12; i++)
            {
                if (d2 <= month[i])
                    break;
                d2 = d2 - month[i];
            }
            actualDay = d2;
            actualMonth = i;
        }

    }
}
