﻿using System;
using DateProblem;

    Console.WriteLine("Enter year in the format dd-mm-yyyy");
    DateTime dt = Convert.ToDateTime(Console.ReadLine());

    int m = dt.Month;
    int d = dt.Day;
    int y = dt.Year;

    Console.WriteLine("Enter the integer that needs to be added");
    int x = Convert.ToInt32(Console.ReadLine());

    DateIssue date = new DateIssue(d, m, y);
    date.addDays(d, m, y, x);


