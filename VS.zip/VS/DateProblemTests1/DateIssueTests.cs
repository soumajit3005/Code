﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DateProblem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateProblem.Tests
{
    [TestClass()]
    public class DateIssueTests
    {
        [TestMethod()]
        public void addDaysTest_WithSmallValue()
        {
            int date = 22;
            int month = 02;
            int year = 2022;
            int x = 6;
            DateIssue d = new DateIssue(date, month, year);
            d.addDays(date, month, year, x);

            Assert.AreEqual(28, d.day);
            Assert.AreEqual(2, d.month);
            Assert.AreEqual(2022, d.year);
        }

        [TestMethod()]
        public void addDaysTest_WithLargeValue()
        {
            int date = 22;
            int month = 02;
            int year = 2022;
            int x = 660;
            DateIssue d = new DateIssue(date, month, year);
            d.addDays(date, month, year, x);

            Assert.AreEqual(14, d.day);
            Assert.AreEqual(12, d.month);
            Assert.AreEqual(2023, d.year);
        }

        [TestMethod()]
        public void addDaysTest_WithNegativeValue()
        {
            int date = 22;
            int month = 02;
            int year = 2022;
            int x = -6;
            DateIssue d = new DateIssue(date, month, year);
            d.addDays(date, month, year, x);

            Assert.AreEqual(16, d.day);
            Assert.AreEqual(2, d.month);
            Assert.AreEqual(2022, d.year);
        }
    }
}